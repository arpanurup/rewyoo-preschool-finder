import io
import json
import re
import time
from urllib.parse import urlparse, urlunparse
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
import requests
import streamlit as st
from bs4 import BeautifulSoup
from ddgs import DDGS

st.set_page_config(page_title="Rewyoo Preschool Finder", page_icon="🏫", layout="wide")
st.title("Rewyoo Preschool Finder")
st.caption("Discover publicly indexed preschool listings and websites across India.")

FIELDS = [
    "Preschool Name", "Branch Name", "Website", "Email", "Phone Number",
    "Alternate Phone", "Full Address", "Locality", "Pincode", "District",
    "State", "Country", "Preschool Type", "Category", "Established Year"
]
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"

if "results" not in st.session_state:
    st.session_state.results = []
if "history" not in st.session_state:
    st.session_state.history = []

st.header("1. Search location")
a, b, c = st.columns(3)
with a:
    locality = st.text_input("Locality", "Whitefield")
    pincode = st.text_input("Pincode (optional)", "560066")
with b:
    city = st.text_input("City", "Bengaluru")
    district = st.text_input("District", "Bengaluru Urban")
with c:
    state = st.text_input("State", "Karnataka")
    country = st.text_input("Country", "India")

st.header("2. Search settings")
limit = st.selectbox("Maximum records", [10, 50, 100, 300, 500], index=0)
categories = st.multiselect(
    "Preschool categories",
    ["Preschool", "Playschool", "Montessori", "Nursery School", "Kindergarten", "Daycare and Preschool"],
    default=["Preschool", "Playschool", "Montessori", "Nursery School", "Kindergarten", "Daycare and Preschool"]
)
st.caption("The selected number is a maximum, not a guaranteed count. Pincode is supporting evidence, not a mandatory filter.")

def clean(x):
    if x is None:
        return ""
    if isinstance(x, (list, tuple)):
        x = " ".join(map(str, x))
    return re.sub(r"\s+", " ", str(x)).strip()

def norm(x):
    return re.sub(r"[^a-z0-9]", "", clean(x).lower())

def canon(url):
    try:
        p = urlparse(url if "://" in url else "https://" + url)
        if not p.netloc:
            return ""
        return urlunparse((p.scheme, p.netloc.lower(), p.path.rstrip("/"), "", "", ""))
    except Exception:
        return ""

def phones(text):
    found = re.findall(r"(?:\+91[\s().-]*)?[6-9]\d(?:[\s().-]*\d){8}", text or "")
    out = []
    for x in found:
        d = re.sub(r"\D", "", x)
        if len(d) == 10:
            out.append(d)
        elif len(d) == 12 and d.startswith("91"):
            out.append(d[2:])
    return list(dict.fromkeys(out))

def emails(text):
    return list(dict.fromkeys(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text or "")))

def pin_from(text):
    m = re.search(r"\b[1-9][0-9]{5}\b", text or "")
    return m.group(0) if m else ""

def flatten_jsonld(data):
    out = []
    if isinstance(data, list):
        for x in data:
            out.extend(flatten_jsonld(x))
    elif isinstance(data, dict):
        if "@graph" in data:
            out.extend(flatten_jsonld(data["@graph"]))
        else:
            out.append(data)
    return out

def address_from(obj):
    addr = obj.get("address", "") if isinstance(obj, dict) else ""
    if isinstance(addr, str):
        return clean(addr)
    if isinstance(addr, dict):
        parts = [addr.get("streetAddress"), addr.get("addressLocality"),
                 addr.get("addressRegion"), addr.get("postalCode"), addr.get("addressCountry")]
        return ", ".join(clean(x) for x in parts if x)
    return ""

def fetch(url):
    try:
        r = requests.get(url, headers={"User-Agent": UA}, timeout=9, allow_redirects=True)
        if r.status_code != 200 or ("html" not in r.headers.get("Content-Type", "").lower() and "<html" not in r.text[:500].lower()):
            return {}
        soup = BeautifulSoup(r.text, "html.parser")
        title = clean(soup.title.get_text(" ", strip=True)) if soup.title else ""
        h1 = soup.find("h1")
        heading = clean(h1.get_text(" ", strip=True)) if h1 else ""
        meta = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
        desc = clean(meta.get("content", "")) if meta else ""
        data = []
        for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
            try:
                data.extend(flatten_jsonld(json.loads(script.string or script.get_text())))
            except Exception:
                pass
        for tag in soup(["script", "style", "noscript", "svg", "header", "footer"]):
            tag.decompose()
        return {"url": canon(r.url) or url, "title": title, "heading": heading,
                "desc": desc, "text": clean(soup.get_text(" ", strip=True))[:30000], "jsonld": data}
    except Exception:
        return {}

def preschool_signal(text):
    t = (text or "").lower()
    return any(x in t for x in [
        "preschool", "pre-school", "playschool", "play school", "playgroup",
        "montessori", "kindergarten", "nursery school", "daycare", "day care",
        "early learning", "pre primary", "pre-primary", "childcare centre"
    ])

def location_score(text, loc):
    t = (text or "").lower()
    locality, city, district, state, country, pin = loc
    score = 0
    if locality and locality.lower() in t: score += 3
    if city and city.lower() in t: score += 2
    if district and district.lower() in t: score += 1
    if state and state.lower() in t: score += 2
    if country and country.lower() in t: score += 1
    if pin and pin in t: score += 2
    if city.lower() in ("bengaluru", "bangalore") and ("bengaluru" in t or "bangalore" in t):
        score = max(score, 2)
    return score

def infer_type(text):
    t = (text or "").lower()
    if "montessori" in t: return "Montessori"
    if "daycare" in t or "day care" in t: return "Daycare / Preschool"
    if "kindergarten" in t: return "Kindergarten"
    if "playschool" in t or "play school" in t or "playgroup" in t: return "Play School"
    if "nursery" in t: return "Nursery / Preschool"
    return "Preschool"

def year_from(text):
    m = re.search(r"(?:established|founded|since|est\.?)\s*(?:in\s*)?(19\d{2}|20\d{2})", text or "", re.I)
    return m.group(1) if m else ""

def make_queries(loc, cats):
    locality, pin, city, district, state, country = loc
    mapping = {
        "Preschool": ["preschool", "pre-school"],
        "Playschool": ["playschool", "play school", "playgroup"],
        "Montessori": ["Montessori preschool", "Montessori school"],
        "Nursery School": ["nursery school", "nursery preschool"],
        "Kindergarten": ["kindergarten", "junior kindergarten"],
        "Daycare and Preschool": ["daycare preschool", "day care and preschool"],
    }
    terms = [term for cat in cats for term in mapping.get(cat, [])] or ["preschool", "playschool"]
    place = " ".join(x for x in [locality, city, district, state, country] if x)
    q = [f'{term} in "{locality}" "{city}" "{state}" {country}' for term in terms]
    q += [
        f'preschool address phone "{locality}" "{city}" {state} India',
        f'playschool branches "{locality}" "{city}" {state} India',
        f'Montessori daycare preschool "{locality}" "{city}" India',
        f'preschool near {pin} {city} India' if pin else f'preschool {place}',
        f'preschool directory listings "{locality}" "{city}" India'
    ]
    return list(dict.fromkeys(q))

def extract_record(hit, page, loc):
    title, snippet, url = hit["title"], hit["snippet"], hit["url"]
    pt = page.get("title", "")
    h1 = page.get("heading", "")
    desc = page.get("desc", "")
    body = page.get("text", "")
    evidence = " ".join([title, snippet, pt, h1, desc, body])
    if not preschool_signal(evidence):
        return None
    locality, pin, city, district, state, country = loc
    if location_score(evidence, loc) < (3 if locality else 2):
        return None

    business = []
    for obj in page.get("jsonld", []):
        typ = obj.get("@type", "")
        typ = " ".join(typ) if isinstance(typ, list) else str(typ)
        if obj.get("name") and any(x in typ.lower() for x in [
            "localbusiness", "preschool", "school", "childcare", "educationalorganization", "organization"
        ]):
            business.append(obj)
    obj = business[0] if business else {}
    name = clean(obj.get("name")) or h1 or title
    if not name or len(name) > 140 or any(x in name.lower() for x in [
        "top 10", "best schools", "list of", "preschools in", "directory"
    ]):
        return None

    address = address_from(obj)
    evidence_detail = " ".join([address, snippet, body[:15000]])
    ph = phones(" ".join([clean(obj.get("telephone")), snippet, body[:18000]]))
    em = emails(" ".join([clean(obj.get("email")), snippet, body[:18000]]))
    website = clean(obj.get("url")) or page.get("url") or url
    if not website.startswith("http"): website = url
    found_pin = pin_from(address) or pin_from(snippet) or pin_from(body[:18000])
    local_value = locality if locality and locality.lower() in evidence_detail.lower() else ""
    if not local_value and city and city.lower() in evidence_detail.lower(): local_value = city

    return {
        "Preschool Name": name,
        "Branch Name": "",
        "Website": website,
        "Email": clean(obj.get("email")) or (em[0] if em else ""),
        "Phone Number": ph[0] if ph else "",
        "Alternate Phone": ph[1] if len(ph) > 1 else "",
        "Full Address": address,
        "Locality": local_value,
        "Pincode": found_pin,
        "District": district if district and district.lower() in evidence_detail.lower() else "",
        "State": state if state and state.lower() in evidence_detail.lower() else "",
        "Country": country if country and country.lower() in evidence_detail.lower() else "",
        "Preschool Type": infer_type(evidence),
        "Category": "Preschool + Daycare" if ("daycare" in evidence.lower() or "day care" in evidence.lower()) else "Preschool",
        "Established Year": year_from(evidence),
        "_source": url,
    }

def dedupe(rows):
    result = {}
    for row in rows:
        name = norm(row["Preschool Name"])
        addr = norm(row["Full Address"])
        phone = norm(row["Phone Number"])
        source = canon(row.get("_source", ""))
        # Same website can represent multiple branches; do not dedupe by domain alone.
        key = (name, addr) if addr else ((name, phone) if phone else (name, source))
        if key not in result:
            result[key] = row
        else:
            old = result[key]
            if sum(bool(old.get(x)) for x in FIELDS) < sum(bool(row.get(x)) for x in FIELDS):
                result[key] = row
    return list(result.values())

def run_search(loc, cats, max_records):
    queries = make_queries(loc, cats)
    progress = st.progress(0)
    status = st.empty()
    found = {}
    for i, query in enumerate(queries, 1):
        status.info(f"Searching {i} of {len(queries)}: {query}")
        try:
            with DDGS() as ddgs:
                for item in ddgs.text(query, region="in-en", safesearch="moderate", max_results=20):
                    url = canon(item.get("href", ""))
                    if url:
                        found.setdefault(url, {
                            "url": url,
                            "title": clean(item.get("title", "")),
                            "snippet": clean(item.get("body", ""))
                        })
        except Exception as exc:
            st.warning(f"Search query failed: {type(exc).__name__}")
        progress.progress(i / len(queries))
        time.sleep(0.3)

    if not found:
        progress.empty()
        status.warning("The search provider returned no pages. Try again later or broaden the location.")
        return []

    status.info(f"Found {len(found)} unique pages. Checking pages for preschool and location evidence...")
    hits = list(found.values())[:max(80, max_records * 4)]
    page_progress = st.progress(0)
    rows = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(fetch, hit["url"]): hit for hit in hits}
        done = 0
        for future in as_completed(futures):
            hit = futures[future]
            try:
                page = future.result()
            except Exception:
                page = {}
            record = extract_record(hit, page, loc)
            if record:
                rows.append(record)
            done += 1
            page_progress.progress(done / max(len(hits), 1))

    rows = dedupe(rows)[:max_records]
    for row in rows:
        row.pop("_source", None)
    progress.empty()
    page_progress.empty()
    status.empty()
    return rows

st.header("3. Start data extraction")
if st.button("Start Preschool Search", type="primary", use_container_width=True):
    if not any([locality.strip(), city.strip(), district.strip()]):
        st.error("Enter at least a locality, city or district.")
    elif not state.strip() or not country.strip():
        st.error("State and Country are required.")
    else:
        location = (locality.strip(), pincode.strip(), city.strip(),
                    district.strip(), state.strip(), country.strip())
        with st.spinner("Searching public web pages and checking location evidence..."):
            st.session_state.results = run_search(location, categories, limit)
        st.session_state.history.append({
            "Locality": locality, "Pincode": pincode, "City": city,
            "District": district, "State": state, "Country": country,
            "Records Found": len(st.session_state.results),
            "Date": time.strftime("%Y-%m-%d %H:%M")
        })
        if st.session_state.results:
            st.success(f"Completed. {len(st.session_state.results)} records collected.")
        else:
            st.warning("No records passed the checks. This does not mean there are no preschools in the area.")

if st.session_state.results:
    st.header("4. Search results")
    df = pd.DataFrame(st.session_state.results, columns=FIELDS)
    st.metric("Records collected", len(df))
    st.dataframe(df, use_container_width=True, hide_index=True)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Preschool Database", index=False)
    st.download_button(
        "Download Excel database", data=buf.getvalue(),
        file_name="Rewyoo_Preschool_Database.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True
    )

if st.session_state.history:
    st.header("5. Search history")
    st.dataframe(pd.DataFrame(st.session_state.history), use_container_width=True, hide_index=True)
    st.caption("Search history is currently stored only in this app session, not permanently.")

st.divider()
st.caption(
    "Open-domain means no website domains are deliberately blocked. Some sites still block automated access, "
    "require sign-in, or do not publish branch details. Review contact information before using it."
)
